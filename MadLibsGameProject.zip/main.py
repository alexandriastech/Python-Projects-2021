#string concatenation (how to put strings together)
# we want to create a string where it says "subscribe to ____"
youtuber = "Alexandria's Tech" 

# a few ways to do this:

print("Subscribe to " + youtuber)
print("Subscribe to {}".format(youtuber))
print(f"Suscribe to {youtuber}")

adj = input("Adjective: ")
verb1 = input("Verb 1: ")
verb2 = input("Verb 2: ")
famous_person = input("Famous Person:  ")

madlib = f"Computer programming is so {adj}!  It makes me so excited all the time because I love to {verb1}. Stay hydrated and {verb2} like you are {famous_person}."

print(madlib)